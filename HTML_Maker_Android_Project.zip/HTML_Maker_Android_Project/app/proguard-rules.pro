# No custom obfuscation rules are required for this first version.
