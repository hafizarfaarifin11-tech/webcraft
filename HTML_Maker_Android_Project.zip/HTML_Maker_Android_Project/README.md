# HTML Maker — Android Project

HTML Maker adalah aplikasi Android untuk menyusun halaman HTML melalui editor visual. Aplikasi memakai WebView lokal; tidak membutuhkan akun, Firebase, atau layanan berbayar.

## Fitur versi 1.0.0

- Menambahkan blok judul, teks, tombol, gambar dari URL HTTPS, garis, dan jarak.
- Mengedit teks, ukuran, warna, latar, posisi, tebal, dan miring.
- Mengatur judul dokumen, warna halaman, font, dan lebar halaman.
- Memilih elemen di kanvas, menggeser urutan elemen, dan menghapus elemen.
- Pratinjau tampilan halaman.
- Ekspor HTML mandiri melalui pemilih lokasi penyimpanan Android.
- Ekspor dan impor proyek JSON.
- Penyimpanan otomatis lokal di perangkat.

## Struktur penting

- `app/src/main/assets/index.html` — antarmuka editor dan generator HTML.
- `app/src/main/java/com/webcraft/htmlmaker/MainActivity.java` — Activity Android dan ekspor file melalui Storage Access Framework.
- `.github/workflows/android.yml` — workflow untuk membangun APK debug.
- `GITHUB_WORKFLOW_TEXT.txt` — salinan teks workflow untuk ditempel manual bila diperlukan.

## Cara membangun APK lewat GitHub

1. Buat repository GitHub baru.
2. Ekstrak ZIP proyek ini, lalu unggah **seluruh isi folder `HTML_Maker_Android_Project`** ke repository. Pastikan folder `.github` ikut terunggah. Idealnya `settings.gradle`, `build.gradle`, dan folder `app` langsung berada di root repository. Workflow versi baru juga mencari `settings.gradle` bila proyek berada satu folder lebih dalam.
3. Commit file ke branch `main`.
4. Buka tab **Actions** di repository. Workflow **Build HTML Maker APK** akan berjalan otomatis setelah push. Bisa juga jalankan lewat tombol **Run workflow**.
5. Setelah selesai dan statusnya hijau, buka proses workflow tersebut, lalu unduh artifact **HTML-Maker-debug-APK**.
6. Ekstrak artifact ZIP dan instal `app-debug.apk` di perangkat Android.

## Membangun dari terminal

Di Linux/macOS dengan JDK 17, Android SDK, Gradle 8.9, dan koneksi internet, jalankan:

```bash
gradle --no-daemon assembleDebug
```

Workflow GitHub Actions tidak lagi membutuhkan file `gradlew`; Gradle 8.9 diunduh langsung pada runner. Launcher `gradlew` yang disertakan di ZIP hanya untuk kemudahan build lokal.

APK debug akan dibuat di:

`app/build/outputs/apk/debug/app-debug.apk`

## Catatan penggunaan

- File HTML yang diekspor tidak berisi kode aplikasi Android; hasilnya adalah halaman web biasa.
- Gambar pada versi ini menggunakan URL HTTPS, bukan mengunggah atau menyematkan file gambar ke dalam HTML.
- Ekspor memakai pemilih dokumen Android sehingga pengguna memilih sendiri folder dan nama file.
- Proyek disimpan otomatis di penyimpanan lokal aplikasi. Hapus data aplikasi dapat menghapus proyek lokal yang belum diekspor.
- Target Android proyek disetel ke API 34 agar perilaku layout tetap konsisten pada berbagai perangkat Android baru.
