@echo off
setlocal
set "APP_HOME=%~dp0"
set "GRADLE_VERSION=8.9"
if "%GRADLE_USER_HOME%"=="" set "GRADLE_USER_HOME=%USERPROFILE%\.gradle"
set "GRADLE_HOME=%GRADLE_USER_HOME%\html-maker-distributions\gradle-%GRADLE_VERSION%"
if not exist "%GRADLE_HOME%\bin\gradle.bat" (
  if not exist "%GRADLE_USER_HOME%\html-maker-distributions" mkdir "%GRADLE_USER_HOME%\html-maker-distributions"
  powershell -NoProfile -ExecutionPolicy Bypass -Command "Invoke-WebRequest -Uri 'https://services.gradle.org/distributions/gradle-%GRADLE_VERSION%-bin.zip' -OutFile '%GRADLE_USER_HOME%\html-maker-distributions\gradle-%GRADLE_VERSION%-bin.zip'"
  if errorlevel 1 exit /b 1
  powershell -NoProfile -ExecutionPolicy Bypass -Command "Expand-Archive -Path '%GRADLE_USER_HOME%\html-maker-distributions\gradle-%GRADLE_VERSION%-bin.zip' -DestinationPath '%GRADLE_USER_HOME%\html-maker-distributions' -Force"
  if errorlevel 1 exit /b 1
  del "%GRADLE_USER_HOME%\html-maker-distributions\gradle-%GRADLE_VERSION%-bin.zip"
)
call "%GRADLE_HOME%\bin\gradle.bat" -p "%APP_HOME%" %*
exit /b %ERRORLEVEL%
