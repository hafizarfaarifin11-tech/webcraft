package com.webcraft.app;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.webkit.JavascriptInterface;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import java.io.OutputStream;
import java.nio.charset.StandardCharsets;

public class MainActivity extends Activity {
    private static final int REQUEST_CREATE_HTML = 4107;
    private WebView webView;
    private String pendingHtml = "";
    private String pendingFileName = "website.html";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        webView = new WebView(this);
        webView.setBackgroundColor(0xFF090A0F);
        setContentView(webView);

        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setLoadsImagesAutomatically(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(false);
        settings.setSupportZoom(false);
        settings.setBuiltInZoomControls(false);
        settings.setDisplayZoomControls(false);

        webView.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                // Keep the app inside its bundled offline workspace.
                return !"file".equals(request.getUrl().getScheme());
            }
        });

        webView.addJavascriptInterface(new WebCraftBridge(), "Android");
        webView.loadUrl("file:///android_asset/index.html");
    }

    private class WebCraftBridge {
        @JavascriptInterface
        public void exportHtml(String fileName, String html) {
            runOnUiThread(() -> {
                pendingFileName = sanitizeFileName(fileName);
                pendingHtml = html == null ? "" : html;

                Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
                intent.addCategory(Intent.CATEGORY_OPENABLE);
                intent.setType("text/html");
                intent.putExtra(Intent.EXTRA_TITLE, pendingFileName);

                try {
                    startActivityForResult(intent, REQUEST_CREATE_HTML);
                } catch (Exception error) {
                    Toast.makeText(MainActivity.this, "Tidak bisa membuka pemilih file.", Toast.LENGTH_LONG).show();
                }
            });
        }

        @JavascriptInterface
        public void showMessage(String message) {
            runOnUiThread(() -> Toast.makeText(MainActivity.this, message, Toast.LENGTH_SHORT).show());
        }
    }

    private String sanitizeFileName(String value) {
        if (value == null || value.trim().isEmpty()) return "website.html";
        String safe = value.trim().replaceAll("[^a-zA-Z0-9._-]", "_");
        if (!safe.toLowerCase().endsWith(".html")) safe += ".html";
        return safe;
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode != REQUEST_CREATE_HTML) return;

        if (resultCode == RESULT_OK && data != null && data.getData() != null) {
            Uri destination = data.getData();
            try (OutputStream output = getContentResolver().openOutputStream(destination)) {
                if (output == null) throw new IllegalStateException("Output stream unavailable");
                output.write(pendingHtml.getBytes(StandardCharsets.UTF_8));
                output.flush();
                Toast.makeText(this, "HTML berhasil diekspor: " + pendingFileName, Toast.LENGTH_LONG).show();
            } catch (Exception error) {
                Toast.makeText(this, "Gagal menyimpan HTML. Coba pilih folder lain.", Toast.LENGTH_LONG).show();
            }
        }
        pendingHtml = "";
    }

    @Override
    @SuppressWarnings("deprecation")
    public void onBackPressed() {
        if (webView == null) {
            super.onBackPressed();
            return;
        }
        webView.evaluateJavascript(
                "window.handleAndroidBack ? window.handleAndroidBack() : false",
                value -> {
                    if (!"true".equals(value)) super.onBackPressed();
                }
        );
    }

    @Override
    protected void onDestroy() {
        if (webView != null) {
            webView.removeJavascriptInterface("Android");
            webView.destroy();
            webView = null;
        }
        super.onDestroy();
    }
}
