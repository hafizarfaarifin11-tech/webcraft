# WebCraft Android

WebCraft adalah website builder sederhana yang berjalan offline di Android. Pengguna bisa memilih template, mengubah teks dan warna, mengatur bagian halaman, melihat preview, menyimpan project di perangkat, lalu mengekspor website sebagai file HTML.

## Fitur versi 1.0

- 3 template awal: Portfolio, Business, dan Link in Bio.
- Editor visual untuk nama website, judul, deskripsi, tombol, link, dan kontak.
- Pengaturan warna aksen, dark/light, rounded/sharp, dan gaya minimal/modern.
- Toggle bagian About, Services, dan Contact.
- Live preview dengan mode mobile dan desktop.
- Simpan dan buka kembali project menggunakan penyimpanan lokal perangkat.
- Ekspor menjadi file `.html` melalui pemilih lokasi Android.
- Tidak membutuhkan akun, Firebase, atau koneksi internet untuk fitur utama.

## Cara mendapatkan APK lewat GitHub

1. Download ZIP project ini, lalu ekstrak.
2. Buat repository baru di GitHub.
3. Upload **isi folder** `WebCraft_GitHub_Project` ke root repository (folder `.github` juga harus ikut ter-upload).
4. Pastikan branch utama bernama `main` atau `master`.
5. Buka tab **Actions** di repository. Workflow **Build WebCraft APK** akan berjalan setelah push. Kalau belum berjalan, pilih workflow itu lalu tekan **Run workflow**.
6. Buka proses build yang paling baru dan tunggu sampai statusnya hijau / **Success**.
7. Di bagian **Artifacts**, download `WebCraft-debug-apk`.
8. Ekstrak file artifact ZIP, lalu install `app-debug.apk` di Android.

## Build manual dengan Android Studio

- Buka folder project ini di Android Studio.
- Gunakan JDK 17.
- Tunggu Gradle sync selesai.
- Pilih **Build > Build Bundle(s) / APK(s) > Build APK(s)**.

APK dari workflow ini adalah **debug APK** untuk pengujian dan pemakaian pribadi. Untuk rilis publik, buat konfigurasi signing release sendiri dan simpan keystore/password sebagai GitHub Secrets; jangan taruh keystore atau password di repository.

## Catatan

- Project ini tidak mengirim konten website atau data project ke server.
- Project yang disimpan berada di local storage aplikasi. Menghapus data aplikasi dapat menghapus project yang belum diekspor.
- File HTML hasil ekspor adalah website statis. Lu bisa mengunggahnya ke hosting statis atau membukanya di browser.
